$(document).ready(function () {
    var img;
    var count;
    var num = 1;
    var next_btn = document.getElementById('next');

    img = $('#slide ul');
    count = img.children().length;

    $('#back').click(function () {
        back();
    });
    $('#next').click(function () {
        next();
    });

    function back() {
        if(1<num) {
            img.animate({
                left: '+=960px'
            });
            num--;
        }
    }
    function next() {
        if(count>=num) {
            img.animate({
                left: '-=960px'
            });
            num++;
        }
        else if(count<=num) {
            next_btn.disabled = 'disabled';
        }

    }
});